<template>
    <div class="card card-body">
        <h2>카드 추천</h2>
    </div>
</template>
