package org.scoula.board.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class BoardVO {
    private Long no;
    private String title;
    private String content;
    private String writer;

    // 첨부 파일
    private List<BoardAttachmentVO> attaches;

    private Date regDate;
    private Date updateDate;


}
